-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: custsql-ipg07.eigbox.net
-- Generation Time: Dec 19, 2012 at 09:16 AM
-- Server version: 5.0.91
-- PHP Version: 4.4.9
-- 
-- Database: `rucrazy`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `payment`
-- 

CREATE TABLE `payment` (
  `pid` int(11) NOT NULL auto_increment,
  `uid` varchar(50) NOT NULL,
  `type` varchar(15) NOT NULL,
  `ccnum` int(25) NOT NULL,
  `name` varchar(75) NOT NULL,
  `month` int(5) NOT NULL,
  `year` int(5) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(5) NOT NULL,
  `zip` int(25) NOT NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `payment`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `product`
-- 

CREATE TABLE `product` (
  `pid` int(11) NOT NULL auto_increment,
  `src` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `desc` varchar(700) NOT NULL,
  `price` int(11) NOT NULL,
  `gender` varchar(11) NOT NULL,
  `brand` varchar(25) NOT NULL,
  `section` varchar(25) NOT NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1 AUTO_INCREMENT=62 ;

-- 
-- Dumping data for table `product`
-- 

INSERT INTO `product` VALUES (1, '../includes/images/top/00001.jpg', 'Cutter & Buck Journey Supima Flatback Half Zip Swe', 'Sweater with embroidered School logo, 100% Cotton Flatback Rib. Double layer rib collar, half zip and metal zipper pull.', 90, 'male', 'Cutter&Buck', 'top');
INSERT INTO `product` VALUES (2, '../includes/images/top/00002.jpg', 'League Rockland Crew', 'Crew with screen printed School Logo in two locations, 80% Cotton 20% Polyester.', 36, 'male', '0', 'top');
INSERT INTO `product` VALUES (3, '../includes/images/top/00003.jpg', 'Nike Element Half Zip Mens Running Top', 'Lightweight Dri-FIT? fabric helps keep you comfortable by moving sweat off your skin for rapid evaporation. Half-length zipper allows on-demand ventilation; windflap wraps the top of the zipper to protect chin from abrasion. Fabric panels under arms vent excess body heat. Thumbholes keep sleeves in place when arms are in motion and enhance warmth. Use the reflective loop at the back of the neck to corral your music-player earphone cord. Flatlock seams reduce chafing and increase comfort.', 60, 'male', 'Nike', 'top');
INSERT INTO `product` VALUES (4, '../includes/images/top/00004.jpg', 'Nike Element Shield Max Mens Running Jacket', 'Wind and water protection. Stretch panels for range of motion. 3D textured Dri-FIT fabric keeps you dry and prevents cling from sweat. 360° reflectivity. Detachable hood and cuff gaiters. 100% polyes', 200, 'male', 'Nike', 'top');
INSERT INTO `product` VALUES (5, '../includes/images/top/00005.jpg', 'Rutgers Nike Cotton Logo Art Tee', 'Cotton logo as art tee is short sleeve with center front school logo. 100% combined ringspun cotton.', 27, 'male', '0', 'top');
INSERT INTO `product` VALUES (6, '../includes/images/top/00006.jpg', 'Rutgers Scarlet Knights Champion Crew Sweatshirt', 'Crewneck sweatshirt with screen printed Rutgers University, 50% Cotton / 50% Polyester. Let your Rutgers pride show.', 20, 'male', '0', 'top');
INSERT INTO `product` VALUES (7, '../includes/images/top/00007.jpg', 'Rutgers Scarlet Knights Cutter&Buck Drytec Pique P', 'Pique polo with embroidered Rutgers University, 63% Cotton / 37% Polyester Pique. Classy and Casual Rutgers spirit.', 50, 'male', '0', 'top');
INSERT INTO `product` VALUES (8, '../includes/images/top/00008.jpg', 'UnderArmour - Fitted Longsleeve Mock', 'Channels heat throughout your body. Constructed of 100% waffle weave microfiber. Wicks moisture while displacing your body heat. Cold Gear. ', 40, 'male', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (9, '../includes/images/top/00009.jpg', 'UnderArmour - Mens Heatgear Compression Sleeveless', 'Smooth & sleek HeatGear fabric is durable, comfortable, and won''t weigh you down. 4-Way Stretch fabrication improves range of motion, dries faster and maintains shape. Signature Moisture Transport System wicks sweat to keep you dry. Anti-Odor technology prevents the growth of odor-causing microbes to keep your gear fresher, longer. 30+ UPF protects your skin from the sun''s harmful rays. Smooth Flatlock Seams prevent chafing. Heat-sealed UA logo. 5.0 oz. Polyester/Elastane. ', 25, 'male', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (10, '../includes/images/top/00010.jpg', 'UnderArmour - Mens UA Base 3.0 1-4 Zip Baselayer', 'UA Base™ 3.0 is built to fight the bitter cold without weighing you down. Soft, brushed negative grid interior traps hot air, providing superior warmth. 4-Way Stretch fabrication allows greater mobility and maintains shape. Signature Moisture Transport System wicks sweat away from the body. Quick-dry fabrication keeps you light and comfortable. Anti-Odor technology prevents the growth of odor causing microbes. Raglan sleeve construction and flatlock stitching allow a full range of motion without chafing. 7.0 oz. Polyester/Elastane. ', 60, 'male', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (11, '../includes/images/top/00011.jpg', 'UnderArmour - Mens UA Charged Cotton Longsleeve T-shirt', 'Fabric made from natural cotton, forFabric made from natural cotton, for superior feel, extreme comfort, and UA performance. Lightweight, 4-Way Stretch fabrication improves range of motion and dries faster. Signature Moisture Transport System wicks away sweat to keep you cool, dry, and focused. Double-stitch shoulder seams are smooth and durable, for full mobility. Cotton/Elastane. ', 30, 'male', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (12, '../includes/images/top/00012.jpg', 'UnderArmour - Touch Fitted Shortsleeve', 'Ultra-soft, lightweight fabric gives superior comfort, cotton-like feel, and unrivaled performance. 4-Way Stretch construction improves range of motion and dries faster. Signature Moisture Transport System and quick-dry fabrication keep you drier, longer. Anti-Odor technology prevents the growth of odor-causing microbes to keep your T-shirt fresher, longer. Rolled shoulder seams prevent chafing. 4.6 oz. Polyester/Elastane. ', 22, 'male', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (13, '../includes/images/top/00013.jpg', 'Winning Ways Crew Sweat Shirt', 'Winning Ways long sleeve crew sweat shirt. 100% cotton.', 59, 'male', '0', 'top');
INSERT INTO `product` VALUES (14, '../includes/images/top/00014.jpg', 'Adidas D Rose Full-zip Hoodie', 'Kangaroo pockets. Full zip with hood. Raglan sleeves for freedom of movement. Tonal graphic on left chest. Paying homage to the Rose family, the d rose signature logo features a rose petal to symbolize each family member. 100% polyester fleece. ', 80, 'male', 'Adidas', 'top');
INSERT INTO `product` VALUES (15, '../includes/images/top/00015.jpg', 'Adidas Originals ADI Pinstripe Trefoil Hoodie', 'Kangaroo pocket. Drawcord on large hood. Pin-striped graphic on front. 65% cotton / 35% polyester fleece. ', 55, 'male', 'Adidas', 'top');
INSERT INTO `product` VALUES (16, '../includes/images/top/00016.jpg', 'Adidas Originals AR 2.0 Wind Jacket', 'Front welt pockets. Full zip with stand-up storm collar and drawcord hood. Ribbed cuffs and hem. Contrast color mesh lining for comfort. 100% polyester dobby. ', 64, 'male', 'Adidas', 'top');
INSERT INTO `product` VALUES (17, '../includes/images/top/00017.jpg', 'Adidas Originals Crew Fleece', 'The adidas Originals Crew Fleece is made of comfortable fleece fabric and features the iconic 3-Stripes running down the sleeves and an embroidered Trefoil on the chest -- making this your next favorite go-to casual closet staple. 70% cotton/30% polyester fleece. Imported', 30, 'male', 'Adidas', 'top');
INSERT INTO `product` VALUES (18, '../includes/images/top/00018.jpg', 'Adidas Squadra II Jersey', 'Moisture-wicking CLIMALITE® fabrication. adidas brandmark on upper right chest. 100% polyester circular rib-knit. ', 28, 'male', 'Adidas', 'top');
INSERT INTO `product` VALUES (19, '../includes/images/top/01001.jpg', 'Nike Element Shield Full Zip Womens Running Jacket', 'Nike Sphere Dry fabric to wick sweat away, reducing cling and helping you stay dry and comfortable. Dri-FIT fabric to wick away sweat and help keep you dry and comfortable. Laminate finish to help protect against wind. Thumbholes for enhanced warmth. Reflective details for enhanced visibility in low-light conditions. Back zip pocket for secure storage. Machine wash. Fabric: Body: 100% polyester. Panels: Dri-FIT 88% polyester/12% spandex. Liner: Sphere Dry 100% polyester. Inner collar: Dri-FIT 100% polyester. ', 115, 'female', 'Nike', 'top');
INSERT INTO `product` VALUES (20, '../includes/images/top/01002.jpg', 'UnderArmour - Womens Coldgear Fitted Longsleeve Cr', 'Ultra-soft, brushback, knit fabric maximizes comfort and breathability, while maintaining warmth. Lightweight, 4-Way Stretch fabrication improves range of motion and dries faster. Signature Moisture Transport System wicks sweat to keep you dry. Anti-Odor technology prevents the growth of odor-causing microbes. Fitted silhouette supports with a feminine feel. 7.0 oz. Polyester/Elastane. ', 40, 'female', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (21, '../includes/images/top/01003.jpg', 'UnderArmour - Womens Armour Fleece Storm Big Logo ', 'Armour Fleece fabric finished with UA Stormtechnology to repel water. Fully lined with UA Intensity fabric for unrivaled warmth and comfort. Signature Moisture Transport System wicks sweat to keep you dry and light. Lightweight stretch construction improves mobility for full range of motion. Two-piece hood with UA Intensity lining traps heat for extreme warmth. Princess seams create a slimmer, more streamlined silhouette. Exaggerated ribbed cuffs and hem. Side hand pockets. 244g Polyester. ', 55, 'female', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (22, '../includes/images/top/01004.jpg', 'UnderArmour - Womens UA Base', 'UA Base 3.0 is built for extreme cold. Negative grid fabric traps heat in tiny pockets for long-lasting protection against the cold. Quick dry construction wicks moisture to keep you drier, lighter, and more comfortable. Armour Block neutralizes odor-causing microbes to keep your women''s leggings smelling fresher, longer. Lightweight, 4-Way Stretch fabrication improves range of motion and dries faster. Flatlock Seams unlock mobility and eliminate chafing. Performance waistband allows for a comfortable, secure fit. 29” inseam. 4.9 oz. Polyester/Elastane. ', 60, 'female', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (23, '../includes/images/top/01005.jpg', 'Adidas 3-Stripes Jacket', 'Side-seam pockets. Full zip with stand-up collar. Elastic cuffs and hem for fit. Contrast details. 100% polyester tricot. ', 45, 'female', 'Adidas', 'top');
INSERT INTO `product` VALUES (24, '../includes/images/top/01006.jpg', 'Adidas Adifit Jacket', 'CLIMALITE fabric sweeps sweat away from your skin. Front hand pockets. Full zip with stand-up collar and stay-down zipper pull. Raglan sleeves for freedom of movement; Thumb holes on sleeves. Extra-long bottom hem; Pleating detail on center back. 92% polyester / 8% elastane single jersey. ', 30, 'female', 'Adidas', 'top');
INSERT INTO `product` VALUES (25, '../includes/images/top/01007.jpg', 'Adidas Ultimate Track Jacket', 'Front welt pockets. Full zip with stand-up collar. Ribbed cuffs and hem for snug fit. Heathered fabric lining. Contrast details. 80% polyester / 20% cotton doubleknit.', 52, 'female', 'Adidas', 'top');
INSERT INTO `product` VALUES (26, '../includes/images/top/01008.jpg', 'UnderArmour - Womens UA Seamless Essential Sports ', 'Seamless sports bra offering midimpact support Bra features HeatGear and Moisture Transport System.', 30, 'female', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (27, '../includes/images/top/01009.jpg', 'UnderArmour - Womens UA Sonic Bra', 'Built for mid-impact support so you can stay fit and focused. UA Compression women''s sports bras deliver superior comfort and support. Super-light HeatGear fabric delivers superior coverage without weighing you down. Signature Moisture Transport System wicks sweat to keep you dry and light. Lightweight, 4-Way Stretch construction improves mobility and accelerates dry time. Slim racer back design unlocks mobility for chafe-free comfort. Polyester/Elastane. ', 30, 'female', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (28, '../includes/images/top/01010.jpg', 'UnderArmour - Womens UA Sonic Reversible Bra', 'Built for mid-impact support so you can stay fit and focused. UA Compression sports bras deliver superior comfort and support. Super-light HeatGear® fabric delivers superior coverage without weighing you down. Signature Moisture Transport System wicks sweat to keep you dry and light. Lightweight, 4-Way Stretch construction improves mobility and accelerates dry time. Slim racer back design unlocks mobility for chafe-free comfort. Women''s sports bras with reversible construction flips from solid to allover graphic print. Polyester/Elastane. ', 30, 'female', 'UnderArmour', 'top');
INSERT INTO `product` VALUES (29, '../includes/images/bottom/10001.jpg', 'Nike SW 2-in-1 9 Mens Running Shorts', 'Fabric: Dri-FIT 100% polyester. Lining: Dri-FIT 86% polyester, 14% spandex. Elastic waist with drawcord for customized fit. Built-in compression shorts for support and comfort. Mesh side panels for breathability. Interior card/key pocket at back waist for storing small items. Flat-seam construction to minimize chafing. Contrast panels and trim for modern look. 9 in inseam based on size medium. Machine wash. ', 30, 'male', 'Nike', 'bottom');
INSERT INTO `product` VALUES (30, '../includes/images/bottom/10002.jpg', 'Rutgers Scarlet Knight Jansport Open Bottom Pant', 'Jansport Draw String Open Bottom Sweatpants, Vertical Leg Screen Print, 55% Cotton, 45% Poly.', 36, 'male', '0', 'bottom');
INSERT INTO `product` VALUES (31, '../includes/images/bottom/10003.jpg', 'Rutgers Scarlet Knights Champion Banded Pant', 'Sweatpant with screen printed School Logo, 50% Cotton 50% Polyester.', 20, 'male', '0', 'bottom');
INSERT INTO `product` VALUES (32, '../includes/images/bottom/10004.jpg', 'UnderArmour - Mens UA Heatgear Leggings', 'Lightweight, high-performance fabric maximizes comfort and breathability. 4-Way Stretch fabrication improves mobility and accelerates dry time, while maintaining shape. Advanced moisture management technology keeps you cooler and drier. Strategically placed Flatlock Seams add to overall comfort by reducing abrasion in high-impact areas. Internal drawstring cord waistband allows for a secure fit. Anti-Odor technology prevents the growth of odor-causing microbes. UPF 30+ protects against harmful sun rays. Inseam Length: Size LG 26.5" (+/- 1/2" per size). 7.0 oz. Nylon/Elastane. ', 40, 'male', 'UnderArmour', 'bottom');
INSERT INTO `product` VALUES (33, '../includes/images/bottom/10005.jpg', 'UnderArmour - Clipper Short', 'Under Armour 100% polyester short. 12 Inseam, 24 Outseam.', 40, 'male', 'UnderArmour', 'bottom');
INSERT INTO `product` VALUES (34, '../includes/images/bottom/10006.jpg', 'Adidas Originals Legacy Track Pant', 'Rib knit details. Screen print graphics. 100% Cotton.', 50, 'male', 'Adidas', 'bottom');
INSERT INTO `product` VALUES (35, '../includes/images/bottom/10007.jpg', 'Adidas Aventus Shorts', 'CLIMALITE fabric sweeps sweat away from your skin. Internal drawcord on elastic waist. Regular fit. 100% polyester dobby. ', 20, 'male', 'Adidas', 'bottom');
INSERT INTO `product` VALUES (36, '../includes/images/bottom/10008.jpg', 'Adidas D Rose Tech Shorts', 'Side-seam pockets. Flat drawcord on engineered flat-ribbed waist. Moisture-wicking mesh lining for breathability; Mesh side inserts above hems. Derrick Rose satin patch above left and right hems. 100% polyester doubleknit. ', 40, 'male', 'Adidas', 'bottom');
INSERT INTO `product` VALUES (37, '../includes/images/bottom/10009.jpg', 'Adidas Squadra II Shorts', 'CLIMALITE fabric sweeps sweat away from your skin. Drawcord on elastic waist. Applied 3-Stripes down legs. Embroidered adidas brandmark above left hem. 100% polyester. ', 20, 'male', 'Adidas', 'bottom');
INSERT INTO `product` VALUES (38, '../includes/images/bottom/10010.jpg', 'Adidas Tiro 11 Shorts', 'Ventilated CLIMACOOL keeps you dry and comfortable. Drawcord on elastic waist. Mesh inserts for ventilation. Applied 3-Stripes down sides; Embroidered adidas brandmark above left hem. 100% polyester interlock. ', 20, 'male', 'Adidas', 'bottom');
INSERT INTO `product` VALUES (39, '../includes/images/bottom/11001.jpg', 'UnderArmour - Womens UA Base 2.0 Leggings', 'ColdGear UA Base™ 2.0 is highly versatile mid-weight protection for colder conditions and a variety of activity levels. Lightweight, 4-Way Stretch fabrication improves range of motion and dries faster. Signature Moisture Transport System keeps you warm, dry, and comfortable. Anti-Odor technology prevents the growth of odor-causing microbes to keep your leggings fresher, longer. Smooth Flatlock Seams prevent chafing. Performance waistband allows for a comfortable, secure fit. Hidden key pocket on waistband offers additional convenience. 29.5" inseam. 4.5 oz. Polyester/Elastane. ', 40, 'female', 'UnderArmour', 'bottom');
INSERT INTO `product` VALUES (40, '../includes/images/bottom/11002.jpg', 'UnderArmour - Womens UA Sonic 2.5 Shorty', 'Super-light HeatGear fabric delivers superior coverage without weighing you down. Signature Moisture Transport System wicks sweat to keep you dry and light. Lightweight, 4-Way Stretch fabrication improves range of motion and dries faster. Anti-microbial technology keeps your gear smelling fresher, longer. Smooth Flatlock Seams prevent chafing. Wide, flat front waistband delivers superior coverage and a seamless silhouette. 2.5” inseam. 7.0 oz. Polyester/Elastane. ', 25, 'female', 'UnderArmour', 'bottom');
INSERT INTO `product` VALUES (41, '../includes/images/bottom/11003.jpg', 'Adidas 3-Stripes Pants', 'Side-seam pockets. Drawcord on elastic waist. Open hem for ease of movement. 100% polyester tricot. ', 35, 'female', 'Adidas', 'bottom');
INSERT INTO `product` VALUES (42, '../includes/images/bottom/11004.jpg', 'Adidas Gal 34 TI W', 'ColdGear UA Base 2.0 is highly versatile mid-weight protection for colder conditions and a variety of activity levels. Lightweight, 4-Way Stretch fabrication improves range of motion and dries faster. Signature Moisture Transport System keeps you warm, dry, and comfortable. Anti-Odor technology prevents the growth of odor-causing microbes to keep your leggings fresher, longer. Smooth Flatlock Seams prevent chafing. Performance waistband allows for a comfortable, secure fit. Hidden key pocket on waistband offers additional convenience. 29.5" inseam. 4.5 oz. Polyester/Elastane. ', 20, 'female', 'Adidas', 'bottom');
INSERT INTO `product` VALUES (43, '../includes/images/bottom/11005.jpg', 'Adidas Oh-So-Warm Fleece Capris', 'Subtle side hand pockets. Drawcord on ribbed waist. Cuffed bottom hems. Slim fit. 85% cotton / 12% polyester / 3% elastane fleece. ', 40, 'female', 'Adidas', 'bottom');
INSERT INTO `product` VALUES (44, '../includes/images/bottom/11006.jpg', 'Nike Dri FIT Tech Womens Running Tights', 'The Nike Tech Tights: A sleek look with a comfortable, body-mapping fit The Nike Dri-FIT Tech Women''s Running Tights hug the body and hold in warmth on cooler days.', 65, 'female', 'Nike', 'bottom');
INSERT INTO `product` VALUES (45, '../includes/images/shoes/20001.jpg', 'Adidas F5 TRX Synthetic FG Cleats', 'Synthetic upper for light weight and easy cleaning. Asymmetrical lacing and flat laces for larger kicking area and better ball contact. Air mesh lining for comfort and breathability. Die-cut EVA insole for comfort and light weight. AgION odor-resistant technology helps keep feet fresh. TRAXION FG outsole for grip and comfort on firm natural surfaces.', 40, 'male', 'Adidas', 'shoes');
INSERT INTO `product` VALUES (46, '../includes/images/shoes/20002.jpg', 'Adidas F10 TRX FG Cleats', 'Easy to maintain lightweight synthetic upper. Asymmetrical lace design offers a larger kicking surface. Die-cut EVA insole for comfort. Agion Technology is used in the lining to eliminate odor and bacteria growth. TRAXION outsole delivers unmatched acceleration and grip on natural surfaces.', 40, 'male', 'Adidas', 'shoes');
INSERT INTO `product` VALUES (47, '../includes/images/shoes/20003.jpg', 'Adidas Predito LZ TRX FG Cleats', 'Engineered predator 3-D TPU technology in five lethal zones for technical perfection with every ball contact. Synthetic leather upper for light weight and durability. Textile lining for comfort. Die-cut EVA midsole for comfort and shock absorption. TRAXION FG outsole for grip and comfort on firm natural surfaces.', 50, 'male', 'Adidas', 'shoes');
INSERT INTO `product` VALUES (48, '../includes/images/shoes/21001.jpg', 'Nike Free Run 3 Shield Womens Running Shoe b/b', 'Run any day, any hour with the Nike Free Run 3 Shield. This shoe''s waterproof upper keeps out rain while the fully reflective fabric shines bright in low light conditions. The flexible midsole is soft and padded, with a slightly lowered heel to encourage a more natural footstrike. A stretchy upper uses an adaptable arch that wraps your foot for a personalized fit.', 100, 'female', 'Nike', 'shoes');
INSERT INTO `product` VALUES (49, '../includes/images/shoes/21002.jpg', 'Nike Free Run 3 Shield Womens Running Shoe w/r', 'Breathable mesh increases air circulation. Multi-layer construction in the upper gives a second-skin fit. Off-center lacing and full inner sleeve boosts comfort. Adaptive fit midfoot construction for custom feel. Sculpted Phylite midsole offers unrivaled cushioning. Deep Nike Free sipes add flexibility, barefoot feel. BRS 1000 carbon rubber heel absorbs shock and increases durability. Environmentally-preferred rubber improves traction on any ground. Waffle piston outsole provides each stride with responsive cushioning. Nike®+ ready.', 100, 'female', 'Nike', 'shoes');
INSERT INTO `product` VALUES (50, '../includes/images/shoes/21003.jpg', 'Nike Air Max 2012 Womens Running Shoe', 'The Nike Air Max+ 2012 running shoe offers maximum cushioning and innovative design elements for the ultimate in performance and style. Two-layer Hyperfuse upper with notched innersleeve delivers lightweight, flexible support and seamless comfort. A molded collar helps reduce heel slip. Cushlon midsole with a full-length Max Air unit provides plush, durable cushioning for the ultimate ride. Flex grooves encourage a smooth transition. BRS 1000 carbon rubber under the heel. Solid rubber with strategically-placed lugs covers the rest of the outsole to give durable traction. Removable insole.', 130, 'female', 'Nike', 'shoes');
INSERT INTO `product` VALUES (51, '../includes/images/misc/30001.jpg', 'Rutgers Scarlet Knights Acrylic Travel Mug with Handle', '16 oz mug with Logo.', 10, '', '0', 'misc');
INSERT INTO `product` VALUES (52, '../includes/images/misc/30002.jpg', 'Rutgers Scarlet Knights Dexter the Bear', '15 inch plush teddy bear with Rutgers University logo. Show your Scarlet Knights pride.', 15, '', '0', 'misc');
INSERT INTO `product` VALUES (53, '../includes/images/misc/30003.jpg', 'Rutgers Scarlet Knights Legacy Adjustable Hat', 'Unstructured washed twill cap with embroidered Rutgers University, 100% Cotton. Let''s go Rutgers! ', 25, '', '0', 'misc');
INSERT INTO `product` VALUES (54, '../includes/images/misc/30004.jpg', 'Rutgers Scarlet Knights MCM Wild Bunch Plush Magne', 'Plush lion with Rutgers University Logo tee on magnet. Cute and full of Rutgers spirit this lion will show everyone your RU pride.', 15, '', '0', 'misc');
INSERT INTO `product` VALUES (55, '../includes/images/misc/30005.jpg', 'Rutgers Scarlet Knights Photo Album', 'Celebrate a Rutgers win with a Scarlet Knights Photo Album.  Keep all your fond Rutgers memories in this sturdy album.', 35, '', '0', 'misc');
INSERT INTO `product` VALUES (56, '../includes/images/misc/30006.jpg', 'Rutgers Scarlet Knights Picture Frame', 'The Horizontal Art Glass Frame is an attractive frame hand-painted in team colors in traditional art glass style. It sports both the Rutgers Scarlet Knights logo and wordmark, making this a distinctive, yet subtle, display of team loyalty. Your loveliest photos deserve an equally striking frame.', 30, '', '0', 'misc');
INSERT INTO `product` VALUES (57, '../includes/images/misc/30007.jpg', 'Rutgers Scarlet Knights Sweatshirt Blanket from MV Sport', '54" x 84" blanket with Rutgers University logo. 80% Cotton / 20% Polyester.', 35, '', '0', 'misc');
INSERT INTO `product` VALUES (58, '../includes/images/misc/30008.jpg', 'Adidas 2012 Tropheo Ball Los Angeles Galaxy', 'Machine-stitched construction for soft touch and high durability. Butyl bladder for best air retention. LA Galaxy team name printed on ball. Major League Soccer logo printed on ball. Inflation required. 100% TPU. ', 20, '', 'Adidas', 'misc');
INSERT INTO `product` VALUES (59, '../includes/images/misc/30009.jpg', 'Adidas AC Milan Authentic Ball', 'Machine-stitched nylon and TPU construction for soft touch and high durability. Butyl bladder for best air retention. Printed AC Milan badge. Requires inflation. 100% polyurethane imitation leather. ', 25, '', 'Adidas', 'misc');
INSERT INTO `product` VALUES (60, '../includes/images/misc/30010.jpg', 'Adidas Confederations Cup 2013 Glider Ball', 'Machine-stitched construction for soft touch and high durability Butyl bladder for best air retention Requires inflation 100% TPU ', 25, '', 'Adidas', 'misc');
INSERT INTO `product` VALUES (61, '../includes/images/misc/30011.jpg', 'Adidas F50 Training Goalkeeping Gloves', 'Soft Grip latex palm for good grip and durability in all weather conditions. EVA back hand for softness, durability and shock absorption. Vented slit-wrist closure for easy entry and freedom of movement. Lightweight half-wrap wrist strap. 70% polyurethane / 30% polyester. ', 20, '', 'Adidas', 'misc');

-- --------------------------------------------------------

-- 
-- Table structure for table `sales`
-- 

CREATE TABLE `sales` (
  `sid` int(11) NOT NULL auto_increment,
  `pid` int(11) NOT NULL,
  `sale` int(11) NOT NULL,
  PRIMARY KEY  (`sid`),
  UNIQUE KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `sales`
-- 

INSERT INTO `sales` VALUES (1, 11, 25);
INSERT INTO `sales` VALUES (2, 29, 25);
INSERT INTO `sales` VALUES (3, 40, 15);
INSERT INTO `sales` VALUES (4, 50, 100);
INSERT INTO `sales` VALUES (5, 27, 15);
INSERT INTO `sales` VALUES (6, 38, 15);

-- --------------------------------------------------------

-- 
-- Table structure for table `transaction`
-- 

CREATE TABLE `transaction` (
  `tid` int(11) NOT NULL auto_increment,
  `uid` varchar(50) NOT NULL,
  `cid` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `cost` int(11) NOT NULL,
  PRIMARY KEY  (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `transaction`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `uid` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `phone` int(11) default NULL,
  `campus` varchar(50) default NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` VALUES ('huacyang@gmail.com', '4677c7bd5f330f9292d87b01cba9c869', 'Hua', 'Yang', 2147483647, 'bs');
INSERT INTO `user` VALUES ('jcohen91@eden.rutgers.edu', 'a1361cb85be840d6a2d762c68e4910e2', 'jesse', 'cohen', 0, '');
INSERT INTO `user` VALUES ('alexmota@gmail.com', '7191472eb4c5c8c82f556315f3dd1544', 'Alexio', 'Mota', 975, 'li');
INSERT INTO `user` VALUES ('anhelax3@gmail.com', '912ec803b2ce49e4a541068d495ab570', 'Angela', 'Hon', 0, '');
INSERT INTO `user` VALUES ('test', '202cb962ac59075b964b07152d234b70', 'test', 'you', 0, '');
INSERT INTO `user` VALUES ('test@you.com', '202cb962ac59075b964b07152d234b70', 'hua', 'yang', 0, '');
